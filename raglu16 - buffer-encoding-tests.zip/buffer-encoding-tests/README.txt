To run all the tests, type:

> jest

Or run them individually by:

> cd tests
> jest combined_operations.test.js
const fc = require('fast-check');

const encodings = Array(
    'utf8',
    'utf16le',
    'latin1',
    'ascii',
);

const hex = Array(
    'hex'
);

const base64 = Array(
    'base64'
);

testEncoding(encodings, encodings, encodings, fc.string());
testEncoding(encodings, encodings, hex, fc.hexaString(2, 100));
testEncoding(encodings, hex, encodings, fc.hexaString(2.100));
testEncoding(encodings, encodings, base64, fc.base64String());
testEncoding(encodings, base64, encodings, fc.base64String());

/*------------------ ignore this mental gymnastic ------------------*/
function testEncoding(firstEncodings, secondEncodings, targetEncoding, arbetraryString) {
    var encodingsCopy = [...secondEncodings];

    firstEncodings.forEach(firstEncoding => {
        if (firstEncodings == secondEncodings)
            encodingsCopy.shift();

        encodingsCopy.forEach(secondEncoding => {
            targetEncoding.forEach(targetEncoding => {

                if (firstEncoding != targetEncoding && secondEncoding != targetEncoding) {

                    test(firstEncoding + ' && ' + secondEncoding + ' => ' + targetEncoding, () => {
                        /*------------------ this is the important part ------------------*/
                        fc.assert(
                            fc.property(arbetraryString, input => {

                                if (firstEncodings.concat(secondEncodings).concat(targetEncoding).includes('hex') && input.length % 2 == 1)
                                    input = input.substring(1); //this is for avoiding uneven long hex strings 

                                const firstBuffer = Buffer.from(input, firstEncoding);
                                const secondBuffer = Buffer.from(input, secondEncoding);
                                const firstTargetBuffer = Buffer.from(firstBuffer.toString(firstEncoding), targetEncoding);
                                const secondTargetBuffer = Buffer.from(secondBuffer.toString(secondEncoding), targetEncoding);

                                expect(secondTargetBuffer.toString(targetEncoding)).toEqual(firstTargetBuffer.toString(targetEncoding));
                            })
                        );
                    });
                }
            });
        });
    });
}
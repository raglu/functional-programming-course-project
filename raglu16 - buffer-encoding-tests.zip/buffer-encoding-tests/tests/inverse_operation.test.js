const fc = require('fast-check');

const encodings = Array(
    'utf8',
    'utf16le',
    'latin1',
    'ascii',
);

const hex = Array(
    'hex'
);

const base64 = Array(
    'base64'
);

testEncoding(encodings, encodings, fc.string());
testEncoding(encodings, hex, fc.hexaString(2, 100));
testEncoding(hex, encodings, fc.hexaString(2, 100));
testEncoding(encodings, base64, fc.base64String());
testEncoding(base64, encodings, fc.base64String());

function testEncoding(startEncodings, temporaryEncodings, arbetraryString) {
    startEncodings.forEach(startEncoding => {
        temporaryEncodings.forEach(temporaryEncoding => {

            if (startEncoding != temporaryEncoding) {

                test(startEncoding + ' => ' + temporaryEncoding + ' => ' + startEncoding, () => {

                    fc.assert(
                        fc.property(arbetraryString, input => {

                            if (startEncodings.concat(temporaryEncoding).includes('hex') && input.length % 2 == 1)
                                input = input.substring(1);

                            const firstBuffer = Buffer.from(input, startEncoding);
                            const temporaryBuffer = Buffer.from(firstBuffer.toString(startEncoding), temporaryEncoding);
                            const secondBuffer = Buffer.from(temporaryBuffer.toString(temporaryEncoding), startEncoding);

                            expect(secondBuffer.toString(startEncoding)).toEqual(firstBuffer.toString(startEncoding));
                        })
                    );
                });
            }
        });
    });
}
const fc = require('fast-check');

const encodings = Array(
    'utf8',
    'utf16le',
    'latin1',
    'ascii',
);

const hex = Array(
    'hex'
);

const base64 = Array(
    'base64'
);

testEncoding(encodings, fc.string());
testEncoding(hex, fc.hexaString(2,100));
testEncoding(base64, fc.base64String());

function testEncoding (encodings, arbetraryString) {
    encodings.forEach(encoding => {
        test(encoding, () => {
            
            fc.assert(
                fc.property(arbetraryString, input => {

                    if (encodings.includes('hex') && input.length % 2 == 1)
                        input = input.substring(1);
                    
                    const firstBuffer = Buffer.from(input, encoding);
                    const secondBuffer = Buffer.from(firstBuffer.toString(encoding), encoding);
                    
                    expect(secondBuffer.toString(encoding)).toEqual(firstBuffer.toString(encoding));
                })
                );
            });
        });
    }
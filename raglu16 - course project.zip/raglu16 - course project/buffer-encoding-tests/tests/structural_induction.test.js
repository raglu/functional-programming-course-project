const fc = require('fast-check');

const encodings = Array(
    'utf8',
    'utf16le',
    'latin1',
    'ascii',
);

const hex = Array(
    'hex'
);

const base64 = Array(
    'base64'
);

testEncoding(encodings, fc.string());
testEncoding(hex, fc.hexaString(2, 100));
testEncoding(base64, fc.base64String());

function testEncoding(encodings, arbetraryString) {
    encodings.forEach(encoding => {
        test(encoding, () => {

            fc.assert(
                fc.property(arbetraryString, input => {

                    if (encodings.includes('hex') && input.length % 2 == 1)
                        input = input.substring(1);

                    const fullString = Buffer.from(input, encoding).toString(encoding);


                    const charArray = [...input];
                    var stringArray = new Array();

                    if (encoding == 'hex') {        //avoid unnecessay splitting
                        for (let index = 0; index < charArray.length; index += 2) {
                            stringArray[index / 2] = charArray[index] + charArray[index + 1];
                        }
                    }

                    if (encoding == 'base64') {     //avoid unnecessay splitting
                        for (let index = 0; index < charArray.length; index += 4) {
                            stringArray[index / 4] = charArray[index] + charArray[index + 1] + charArray[index + 2] + charArray[index + 3];
                        }
                    }

                    var concatenatedString = '';

                    if (stringArray.length == 0) {
                        charArray.forEach(c => {
                            concatenatedString += Buffer.from(c, encoding).toString(encoding);
                        });
                    }
                    else {
                        stringArray.forEach(s => {
                            concatenatedString += Buffer.from(s, encoding).toString(encoding);
                        });
                    }

                    expect(concatenatedString).toEqual(fullString);
                })
            );
        });
    });
}